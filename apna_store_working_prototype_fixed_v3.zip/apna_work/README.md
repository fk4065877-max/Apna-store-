# Apna Store — Working Flutter Prototype

This version follows the supplied Apna Store grocery-app design and has a clickable local app flow:

- Splash-style branding can be added as the native launch screen
- Home, categories and product lists
- Product details with weight and quantity
- Add to cart / quantity controls
- Delivery address editing
- Checkout and Cash on Delivery
- Order placement creates a local order ID
- Order tracking timeline
- My Orders
- Profile / account menu

## Run in Android Studio
1. Install Flutter SDK and the Flutter/Dart plugins in Android Studio.
2. Open this folder (`apna_store`) in Android Studio.
3. Run `flutter pub get` in Terminal.
4. Connect an Android phone with USB debugging enabled, or start an Android emulator.
5. Run `flutter devices` and then `flutter run`.

## Important
This is a functional **local prototype**. It does not yet have a real server/database, real GPS/map, login OTP, payment gateway, push notifications, admin panel, or live delivery tracking. Those are the next production integrations before Play Store release.
