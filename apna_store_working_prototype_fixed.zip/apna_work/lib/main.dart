import 'package:flutter/material.dart';

const green = Color(0xFF07883F);
const lightGreen = Color(0xFFEAF8EF);
const bg = Color(0xFFF7F8F6);

void main() => runApp(const ApnaStoreApp());

class Product {
  final String name, category, unit, emoji;
  final int price;
  const Product(this.name, this.category, this.unit, this.price, this.emoji);
}

const products = <Product>[
  Product('Apple', 'Fruits & Vegetables', '1 kg', 280, '🍎'),
  Product('Banana', 'Fruits & Vegetables', '1 dozen', 180, '🍌'),
  Product('Orange', 'Fruits & Vegetables', '1 kg', 220, '🍊'),
  Product('Tomato', 'Fruits & Vegetables', '1 kg', 160, '🍅'),
  Product('Potato', 'Fruits & Vegetables', '1 kg', 120, '🥔'),
  Product('Onion', 'Fruits & Vegetables', '1 kg', 100, '🧅'),
  Product('Fresh Milk', 'Dairy & Eggs', '1 litre', 250, '🥛'),
  Product('Farm Eggs', 'Dairy & Eggs', '12 pcs', 360, '🥚'),
  Product('Bread', 'Bakery', '1 pack', 120, '🍞'),
  Product('Basmati Rice', 'Rice & Pulses', '1 kg', 420, '🍚'),
  Product('Cooking Oil', 'Rice & Pulses', '1 litre', 590, '🫗'),
  Product('Biscuits', 'Snacks & Beverages', 'Pack', 120, '🍪'),
  Product('Tea', 'Snacks & Beverages', '400 g', 620, '☕'),
  Product('Dish Wash', 'Household & Cleaning', '500 ml', 260, '🧴'),
  Product('Shampoo', 'Personal Care', '400 ml', 540, '🧴'),
];

const categories = <String>[
  'Fruits & Vegetables', 'Dairy & Eggs', 'Bakery', 'Rice & Pulses',
  'Snacks & Beverages', 'Spices & Masala', 'Household & Cleaning',
  'Personal Care', 'Baby Care', 'Pet Care'
];

class ApnaStoreApp extends StatelessWidget {
  const ApnaStoreApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Apna Store',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: green),
          scaffoldBackgroundColor: bg,
          appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          ),
        ),
        home: const StoreShell(),
      );
}

class StoreShell extends StatefulWidget {
  const StoreShell({super.key});
  @override
  State<StoreShell> createState() => _StoreShellState();
}

class _StoreShellState extends State<StoreShell> {
  int tab = 0;
  final Map<Product, int> cart = {};
  String address = 'House No. 12, Street 4, Gulshan Colony';
  final orders = <String>[];

  int get count => cart.values.fold(0, (a, b) => a + b);
  double get subtotal => cart.entries.fold(0, (s, e) => s + e.key.price * e.value);
  double get delivery => subtotal >= 1800 ? 0 : (subtotal == 0 ? 0 : 60);
  double get total => subtotal + delivery;

  void add(Product p) => setState(() => cart[p] = (cart[p] ?? 0) + 1);
  void remove(Product p) => setState(() {
        if (!cart.containsKey(p)) return;
        if (cart[p]! <= 1) { cart.remove(p); } else { cart[p] = cart[p]! - 1; }
      });

  void openProduct(Product p) => Navigator.push(context, MaterialPageRoute(
        builder: (_) => ProductPage(product: p, onAdd: () { add(p); Navigator.pop(context); }))); 

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(products: products, cartCount: count, onAdd: add, onOpen: openProduct,
          address: address, onAddress: (v) => setState(() => address = v), onSeeAll: () => setState(() => tab = 1)),
      CategoriesPage(onOpenCategory: (c) => Navigator.push(context, MaterialPageRoute(
          builder: (_) => CategoryPage(category: c, onAdd: add, onOpen: openProduct)))),
      CartPage(cart: cart, subtotal: subtotal, delivery: delivery, total: total, onAdd: add, onRemove: remove,
          onCheckout: cart.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => CheckoutPage(total: total, address: address, onPlace: _placeOrder)))),
      OrdersPage(orderIds: orders),
      ProfilePage(address: address, onAddress: (v) => setState(() => address = v)),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          const NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Categories'),
          NavigationDestination(icon: Badge(isLabelVisible: count > 0, label: Text('$count'), child: const Icon(Icons.shopping_cart_outlined)), label: 'Cart'),
          const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }

  void _placeOrder() {
    final id = '#AS${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    setState(() { orders.insert(0, id); cart.clear(); });
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => OrderTrackingPage(orderId: id)));
  }
}

class HomePage extends StatelessWidget {
  final List<Product> products; final int cartCount; final void Function(Product) onAdd; final void Function(Product) onOpen;
  final String address; final ValueChanged<String> onAddress; final VoidCallback onSeeAll;
  const HomePage({super.key, required this.products, required this.cartCount, required this.onAdd, required this.onOpen,
      required this.address, required this.onAddress, required this.onSeeAll});
  @override
  Widget build(BuildContext context) => CustomScrollView(slivers: [
        SliverAppBar(pinned: true, backgroundColor: green, foregroundColor: Colors.white, title: const Text('Apna Store', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [IconButton(onPressed: onSeeAll, icon: const Icon(Icons.search))]),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 0), child: LocationCard(address: address, onChange: () => editAddress(context, address, onAddress)))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(16), child: TextField(decoration: const InputDecoration(hintText: 'Search for products...', prefixIcon: Icon(Icons.search))))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Container(height: 135, decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(18)), child: Row(children: [
          const Expanded(child: Padding(padding: EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text('Fresh Groceries', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)), Text('at Your Doorstep', style: TextStyle(color: Colors.white, fontSize: 18)), SizedBox(height: 6), Text('Quality • Freshness • Best Prices', style: TextStyle(color: Colors.white70)), SizedBox(height: 10)])),
          Padding(padding: const EdgeInsets.all(14), child: Text('🥬\n🍅 🥕', textAlign: TextAlign.center, style: TextStyle(fontSize: 32))),
        ])))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 18, 16, 8), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Categories', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), TextButton(onPressed: onSeeAll, child: const Text('View All'))]))),
        SliverToBoxAdapter(child: SizedBox(height: 92, child: ListView.builder(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: categories.length, itemBuilder: (_, i) => Padding(padding: const EdgeInsets.only(right: 12), child: Column(children: [CircleAvatar(radius: 28, backgroundColor: lightGreen, child: Text(['🍎','🥛','🍞','🍚','🍪','🌶️','🧴','🧼','🍼','🐶'][i], style: const TextStyle(fontSize: 24))), const SizedBox(height: 5), SizedBox(width: 78, child: Text(categories[i].split(' ').take(2).join(' '), textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 10)))])))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Hot Deals', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), TextButton(onPressed: onSeeAll, child: const Text('View All'))]))),
        SliverPadding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 20), sliver: SliverGrid(delegate: SliverChildBuilderDelegate((_, i) { final p = products[i]; return ProductCard(product: p, onAdd: () => onAdd(p), onOpen: () => onOpen(p)); }, childCount: 6), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .73))),
      ]);
}

class LocationCard extends StatelessWidget {
  final String address; final VoidCallback onChange;
  const LocationCard({super.key, required this.address, required this.onChange});
  @override Widget build(BuildContext context) => Card(child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), leading: const CircleAvatar(backgroundColor: lightGreen, child: Icon(Icons.location_on, color: green)), title: const Text('Deliver to', style: TextStyle(fontSize: 12)), subtitle: Text(address, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), trailing: TextButton(onPressed: onChange, child: const Text('Change'))));
}

class ProductCard extends StatelessWidget {
  final Product product; final VoidCallback onAdd, onOpen;
  const ProductCard({super.key, required this.product, required this.onAdd, required this.onOpen});
  @override Widget build(BuildContext context) => Card(clipBehavior: Clip.antiAlias, child: InkWell(onTap: onOpen, child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(color: lightGreen, borderRadius: BorderRadius.circular(14)), child: Center(child: Text(product.emoji, style: const TextStyle(fontSize: 56))))), const SizedBox(height: 8), Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold)), Text(product.unit, style: const TextStyle(color: Colors.grey, fontSize: 12)), const Spacer(), Row(children: [Expanded(child: Text('Rs. ${product.price}/', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))), IconButton.filled(onPressed: onAdd, icon: const Icon(Icons.add), constraints: const BoxConstraints.tightFor(width: 38, height: 38), padding: EdgeInsets.zero)])]))));
}

class CategoriesPage extends StatelessWidget {
  final ValueChanged<String> onOpenCategory;
  const CategoriesPage({super.key, required this.onOpenCategory});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Categories', style: TextStyle(fontWeight: FontWeight.bold))), body: GridView.builder(padding: const EdgeInsets.all(16), itemCount: categories.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.15), itemBuilder: (_, i) => Card(child: InkWell(onTap: () => onOpenCategory(categories[i]), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(['🥬','🥛','🥐','🍚','🍪','🌶️','🧼','🧴','🍼','🐶'][i], style: const TextStyle(fontSize: 45)), const SizedBox(height: 8), Text(categories[i], textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))]))));
}

class CategoryPage extends StatelessWidget {
  final String category; final void Function(Product) onAdd, onOpen;
  const CategoryPage({super.key, required this.category, required this.onAdd, required this.onOpen});
  @override Widget build(BuildContext context) { final list = products.where((p) => p.category == category).toList(); return Scaffold(appBar: AppBar(title: Text(category)), body: GridView.builder(padding: const EdgeInsets.all(16), itemCount: list.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .73), itemBuilder: (_, i) => ProductCard(product: list[i], onAdd: () => onAdd(list[i]), onOpen: () => onOpen(list[i])))); }
}

class ProductPage extends StatefulWidget {
  final Product product; final VoidCallback onAdd;
  const ProductPage({super.key, required this.product, required this.onAdd});
  @override State<ProductPage> createState() => _ProductPageState();
}
class _ProductPageState extends State<ProductPage> {
  int qty = 1; String weight = '1 kg';
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Product Details')), body: ListView(padding: const EdgeInsets.all(16), children: [
    Container(height: 260, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Center(child: Text(widget.product.emoji, style: const TextStyle(fontSize: 140)))),
    const SizedBox(height: 18), Row(children: [Expanded(child: Text(widget.product.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold))), const Chip(label: Text('Fresh'))]),
    Text('Rs. ${widget.product.price}/kg', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 10), const Row(children: [Icon(Icons.star, color: Colors.amber), Text(' 4.8 (124 reviews)')]),
    const SizedBox(height: 14), const Text('Fresh quality product, selected for your daily grocery needs.'), const SizedBox(height: 22), const Text('Select Weight', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 10), Wrap(spacing: 8, children: ['1 kg','2 kg','5 kg'].map((w) => ChoiceChip(label: Text(w), selected: weight == w, onSelected: (_) => setState(() => weight = w))).toList()),
    const SizedBox(height: 22), const Text('Quantity', style: TextStyle(fontWeight: FontWeight.bold)), Row(children: [IconButton.filledTonal(onPressed: () => setState(() => qty = qty > 1 ? qty - 1 : 1), icon: const Icon(Icons.remove)), Expanded(child: Center(child: Text('$qty', style: const TextStyle(fontSize: 18)))), IconButton.filled(onPressed: () => setState(() => qty++), icon: const Icon(Icons.add))]),
    const SizedBox(height: 20), SizedBox(height: 54, child: FilledButton(onPressed: () { for (var i=0;i<qty;i++) widget.onAdd(); }, child: Text('Add to Cart  •  Rs. ${widget.product.price * qty}'))),
  ]));
}

class CartPage extends StatelessWidget {
  final Map<Product,int> cart; final double subtotal, delivery, total; final void Function(Product) onAdd, onRemove; final VoidCallback? onCheckout;
  const CartPage({super.key, required this.cart, required this.subtotal, required this.delivery, required this.total, required this.onAdd, required this.onRemove, required this.onCheckout});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('My Cart')), body: cart.isEmpty ? const Center(child: Text('Your cart is empty')) : ListView(padding: const EdgeInsets.all(16), children: [
    ...cart.entries.map((e) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: lightGreen, child: Text(e.key.emoji)), title: Text(e.key.name), subtitle: Text('Rs. ${e.key.price} • ${e.key.unit}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => onRemove(e.key), icon: const Icon(Icons.remove_circle_outline)), Text('${e.value}'), IconButton(onPressed: () => onAdd(e.key), icon: const Icon(Icons.add_circle_outline))]))),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [_row('Subtotal', subtotal), _row('Delivery Fee', delivery), const Divider(), _row('Total', total, bold: true), const SizedBox(height: 8), const Row(children: [Icon(Icons.local_shipping_outlined, color: green), SizedBox(width: 8), Text('Estimated delivery: 30–60 minutes')])]))),
    const SizedBox(height: 10), SizedBox(height: 54, child: FilledButton(onPressed: onCheckout, child: const Text('Proceed to Checkout')))
  ]));
  Widget _row(String a, double b, {bool bold=false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)), Text('Rs. ${b.toStringAsFixed(0)}', style: TextStyle(fontWeight: bold ? FontWeight.bold : null))]));
}

class CheckoutPage extends StatefulWidget {
  final double total; final String address; final VoidCallback onPlace;
  const CheckoutPage({super.key, required this.total, required this.address, required this.onPlace});
  @override State<CheckoutPage> createState() => _CheckoutPageState();
}
class _CheckoutPageState extends State<CheckoutPage> {
  String payment = 'Cash on Delivery';
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Checkout')), body: ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Delivery Address', style: TextStyle(fontWeight: FontWeight.bold)), Card(child: ListTile(leading: const Icon(Icons.location_on, color: green), title: const Text('Muhammad Ali'), subtitle: Text(widget.address), trailing: const Text('Change', style: TextStyle(color: green)))),
    const SizedBox(height: 14), const Text('Delivery Time', style: TextStyle(fontWeight: FontWeight.bold)), const Card(child: ListTile(leading: Icon(Icons.schedule, color: green), title: Text('Today'), subtitle: Text('30–60 minutes'))),
    const SizedBox(height: 14), const Text('Payment Method', style: TextStyle(fontWeight: FontWeight.bold)), Card(child: Column(children: [RadioListTile<String>(value: 'Cash on Delivery', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('Cash on Delivery'), subtitle: const Text('Pay when you receive your order')), RadioListTile<String>(value: 'Online Payment', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('Online Payment'), subtitle: const Text('Coming soon'))])),
    const SizedBox(height: 18), Card(child: Padding(padding: const EdgeInsets.all(16), child: _row('Total', widget.total, bold: true))), const SizedBox(height: 12), SizedBox(height: 54, child: FilledButton(onPressed: widget.onPlace, child: const Text('Place Order')))
  ]));
  Widget _row(String a, double b, {bool bold=false}) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)), Text('Rs. ${b.toStringAsFixed(0)}', style: TextStyle(fontWeight: bold ? FontWeight.bold : null))]);
}

class OrderTrackingPage extends StatelessWidget {
  final String orderId;
  const OrderTrackingPage({super.key, required this.orderId});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Track Order')), body: ListView(padding: const EdgeInsets.all(20), children: [Text('Order $orderId', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const Text('Placed just now'), const SizedBox(height: 30), _step('Order Placed', 'Your order has been received', true), _step('Confirmed', 'Store confirmed your order', true), _step('Preparing', 'Your items are being packed', true), _step('Out for Delivery', 'Will be delivered soon', false), _step('Delivered', 'Enjoy your purchase!', false), const SizedBox(height: 20), Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: const Text('Delivery Partner'), subtitle: const Text('Ali Raza'), trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.call, color: green))))]));
  Widget _step(String title, String sub, bool active) => Padding(padding: const EdgeInsets.only(bottom: 22), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(radius: 14, backgroundColor: active ? green : Colors.grey.shade300, child: Icon(active ? Icons.check : Icons.circle, size: 16, color: active ? Colors.white : Colors.grey)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), Text(sub, style: const TextStyle(color: Colors.grey))]))]));
}

class OrdersPage extends StatelessWidget {
  final List<String> orderIds;
  const OrdersPage({super.key, required this.orderIds});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('My Orders')), body: orderIds.isEmpty ? const Center(child: Text('No orders yet')) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: orderIds.length, itemBuilder: (_, i) => Card(child: ListTile(leading: const CircleAvatar(backgroundColor: lightGreen, child: Icon(Icons.receipt_long, color: green)), title: Text(orderIds[i]), subtitle: const Text('Today • Processing'), trailing: const Text('View Details', style: TextStyle(color: green))))));
}

class ProfilePage extends StatelessWidget {
  final String address; final ValueChanged<String> onAddress;
  const ProfilePage({super.key, required this.address, required this.onAddress});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('My Account')), body: ListView(children: [Container(color: green, padding: const EdgeInsets.fromLTRB(20, 20, 20, 24), child: const Row(children: [CircleAvatar(radius: 30, child: Icon(Icons.person)), SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Apna Store Customer', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)), Text('Welcome back!', style: TextStyle(color: Colors.white70))])])), _tile(context, Icons.receipt_long, 'My Orders'), _tile(context, Icons.location_on_outlined, 'My Addresses', onTap: () => editAddress(context, address, onAddress)), _tile(context, Icons.notifications_none, 'Notifications'), _tile(context, Icons.help_outline, 'Support & Help'), _tile(context, Icons.info_outline, 'About Us'), _tile(context, Icons.settings_outlined, 'Settings') ]));
  Widget _tile(BuildContext context, IconData icon, String title, {VoidCallback? onTap}) => ListTile(leading: Icon(icon), title: Text(title), trailing: const Icon(Icons.chevron_right), onTap: onTap ?? () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title is ready for backend connection'))));
}

Future<void> editAddress(BuildContext context, String current, ValueChanged<String> save) async {
  final c = TextEditingController(text: current);
  await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Delivery Address'), content: TextField(controller: c, maxLines: 3, decoration: const InputDecoration(hintText: 'House, street, area, city')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () { if (c.text.trim().isNotEmpty) save(c.text.trim()); Navigator.pop(context); }, child: const Text('Save'))]));
}
